signtool - ad-hoc code signing for re3.app

re3's installer (utils/quick-install.sh) uses this to re-sign re3.app after
baking your game files in, so installing needs nothing but macOS itself. It is
not part of re3, and is redistributed unmodified apart from having its library
paths repointed at @loader_path.

Contents and licences (full texts in LICENSES/):

  ldid                  ldid, procursus fork - AGPL-3.0-or-later
                        Source: https://github.com/ProcursusTeam/ldid
  libcrypto.3.dylib     OpenSSL 3 - Apache-2.0
                        Source: https://github.com/openssl/openssl
  libplist-2.0.4.dylib  libplist - LGPL-2.1-or-later
                        Source: https://github.com/libimobiledevice/libplist

The binaries are Homebrew's arm64_sequoia bottles, downloaded from Homebrew's registry
and checksum-verified by packaging/mac/build-signtool.py.
